/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.2.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDial>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionMain_Page;
    QAction *actionfd;
    QWidget *centralwidget;
    QGroupBox *groupBoxArm;
    QSlider *horizontalSlider_z_arm;
    QLabel *label_Z;
    QComboBox *comboBox_arm_1;
    QLabel *label_z_arm;
    QComboBox *comboBox_arm_2;
    QComboBox *comboBox_arm_3;
    QComboBox *comboBox_arm_4;
    QComboBox *comboBox_arm_5;
    QComboBox *comboBox_arm_6;
    QLabel *label_Y_2;
    QLabel *label_y_arm;
    QSlider *horizontalSlider_x_arm;
    QLabel *label_x_arm;
    QSpinBox *spinBox_power_arm;
    QLabel *label_POWER;
    QSlider *horizontalSlider_power_arm;
    QLabel *label_X_2;
    QSlider *horizontalSlider_y_arm;
    QPushButton *pushButton_button_function_arm_1;
    QPushButton *pushButton_button_function_arm_2;
    QPushButton *pushButton_button_function_arm_3;
    QPushButton *pushButton_button_function_arm_4;
    QPushButton *pushButton_button_function_arm_5;
    QPushButton *pushButton_button_function_arm_6;
    QProgressBar *progressBar_motor_base;
    QProgressBar *progressBar_motor_first;
    QProgressBar *progressBar_motor_second;
    QProgressBar *progressBar_motor_third;
    QProgressBar *progressBar_motor_jaws;
    QProgressBar *progressBar_motor_jaws_clench;
    QLabel *label_motor_base;
    QLabel *label_motor_first;
    QLabel *label_motor_second;
    QLabel *label_motor_third;
    QLabel *label_motor_jaws;
    QLabel *label_motor_jaws_clench;
    QGroupBox *groupBoxDrive;
    QLabel *label_Y;
    QLabel *label_y_drive;
    QSlider *horizontalSlider_x_drive;
    QSlider *horizontalSlider_power_drive;
    QLabel *label_X;
    QLabel *label_power_drive;
    QLabel *label_x_drive;
    QSlider *horizontalSlider_y_drive;
    QSpinBox *spinBox_power_drive;
    QProgressBar *progressBar_wheel_left_back;
    QProgressBar *progressBar_wheel_left_middle;
    QProgressBar *progressBar_wheel_left_front;
    QProgressBar *progressBar_wheel_right_back;
    QProgressBar *progressBar_wheel_right_front;
    QProgressBar *progressBar_wheel_right_middle;
    QGroupBox *groupBox_4;
    QGraphicsView *graphicsView;
    QGroupBox *groupBox_7;
    QTableWidget *tableWidget_nav;
    QLabel *label_18;
    QLabel *label_19;
    QPushButton *pushButton_add_pos;
    QLabel *label_22;
    QLabel *labelChoosenIndex;
    QPushButton *pushButtonDeletePoint;
    QLineEdit *lineEditPosX;
    QLineEdit *lineEditPosY;
    QPushButton *pushButtonUnZoom;
    QPushButton *pushButtonZoom;
    QLabel *label_scale;
    QPushButton *pushButtonRotate;
    QLineEdit *lineEditPosXRover;
    QLineEdit *lineEditPosYRover;
    QLineEdit *lineEditRotate;
    QPushButton *pushButtonSend;
    QPushButton *pushButton;
    QGroupBox *groupBox_2;
    QLabel *label_drive_control;
    QLabel *label_arm_control;
    QComboBox *comboBox_arm_control;
    QComboBox *comboBox_drive_control;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *lineEdit_IP_adress;
    QLineEdit *lineEdit_port;
    QPushButton *pushButton_stop;
    QGroupBox *groupBox_8;
    QLabel *label_frames_received_count;
    QLabel *label_frames_sent_count;
    QLabel *label;
    QLabel *label_8;
    QLabel *label_10;
    QLabel *label_current_ip;
    QLabel *label_2;
    QLabel *label_joysticks_count;
    QGroupBox *groupBox;
    QTextBrowser *textBrowser_printer;
    QGroupBox *groupBox_3;
    QSlider *horizontalSliderPokerAngle;
    QSlider *horizontalSliderPokerPoke;
    QLabel *label_5;
    QLabel *label_6;
    QSpinBox *spinBoxPokerAngle;
    QSpinBox *spinBoxPokerPoke;
    QGroupBox *groupBox_5;
    QLabel *label_science_revolver_value;
    QCheckBox *checkBox_lid_1;
    QCheckBox *checkBox_lid_2;
    QCheckBox *checkBox_lid_3;
    QCheckBox *checkBox_lid_4;
    QCheckBox *checkBox_pump_3;
    QCheckBox *checkBox_pump_4;
    QCheckBox *checkBox_pump_1;
    QCheckBox *checkBox_pump_2;
    QLabel *label_science_revolver_name;
    QPushButton *pushButton_revolver_plus;
    QPushButton *pushButton_revolver_minus;
    QDial *dial_revolver;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1592, 800);
        MainWindow->setAcceptDrops(false);
        MainWindow->setAutoFillBackground(false);
        MainWindow->setStyleSheet(QString::fromUtf8("QMainWindow\n"
"{\n"
"	background: #363062;\n"
"}\n"
"\n"
"QMenuBar\n"
"{\n"
"	background: #363062;\n"
"	color:rgb(255, 255, 255)\n"
"}"));
        MainWindow->setAnimated(true);
        MainWindow->setUnifiedTitleAndToolBarOnMac(false);
        actionMain_Page = new QAction(MainWindow);
        actionMain_Page->setObjectName(QString::fromUtf8("actionMain_Page"));
        actionfd = new QAction(MainWindow);
        actionfd->setObjectName(QString::fromUtf8("actionfd"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setToolTipDuration(-32);
        centralwidget->setStyleSheet(QString::fromUtf8("QWidget\n"
"{\n"
"	background: #363062;\n"
"	color:	#E9D5DA;\n"
"	border-color: rgb(32, 32, 32);\n"
"}\n"
"\n"
"QComboBox\n"
"{\n"
"	background-color: #4D4C7D;\n"
"}\n"
"\n"
"QGroupBox\n"
"{\n"
"	background: rgb(0,0,0,0);\n"
"  	border-color: rgb(100, 100, 100);\n"
"  	border-width: 1px;        \n"
"  	border-style: solid;\n"
"	border-radius:15px;\n"
"}\n"
"\n"
"QLineEdit\n"
"{\n"
"	background-color: rgb(108, 108, 152);\n"
"}\n"
"\n"
"QSpinBox\n"
"{\n"
"	background-color: rgb(108, 108, 152);\n"
"}\n"
"\n"
"QSlider\n"
"{\n"
"	color: rgb(108, 108, 152);\n"
"}"));
        groupBoxArm = new QGroupBox(centralwidget);
        groupBoxArm->setObjectName(QString::fromUtf8("groupBoxArm"));
        groupBoxArm->setGeometry(QRect(10, 10, 511, 351));
        horizontalSlider_z_arm = new QSlider(groupBoxArm);
        horizontalSlider_z_arm->setObjectName(QString::fromUtf8("horizontalSlider_z_arm"));
        horizontalSlider_z_arm->setGeometry(QRect(60, 120, 160, 22));
        horizontalSlider_z_arm->setMinimum(-100);
        horizontalSlider_z_arm->setMaximum(100);
        horizontalSlider_z_arm->setOrientation(Qt::Horizontal);
        label_Z = new QLabel(groupBoxArm);
        label_Z->setObjectName(QString::fromUtf8("label_Z"));
        label_Z->setGeometry(QRect(10, 120, 41, 21));
        comboBox_arm_1 = new QComboBox(groupBoxArm);
        comboBox_arm_1->addItem(QString());
        comboBox_arm_1->addItem(QString());
        comboBox_arm_1->addItem(QString());
        comboBox_arm_1->addItem(QString());
        comboBox_arm_1->addItem(QString());
        comboBox_arm_1->addItem(QString());
        comboBox_arm_1->addItem(QString());
        comboBox_arm_1->setObjectName(QString::fromUtf8("comboBox_arm_1"));
        comboBox_arm_1->setGeometry(QRect(68, 160, 211, 22));
        comboBox_arm_1->setEditable(false);
        label_z_arm = new QLabel(groupBoxArm);
        label_z_arm->setObjectName(QString::fromUtf8("label_z_arm"));
        label_z_arm->setGeometry(QRect(230, 120, 49, 21));
        comboBox_arm_2 = new QComboBox(groupBoxArm);
        comboBox_arm_2->addItem(QString());
        comboBox_arm_2->addItem(QString());
        comboBox_arm_2->addItem(QString());
        comboBox_arm_2->addItem(QString());
        comboBox_arm_2->addItem(QString());
        comboBox_arm_2->addItem(QString());
        comboBox_arm_2->addItem(QString());
        comboBox_arm_2->setObjectName(QString::fromUtf8("comboBox_arm_2"));
        comboBox_arm_2->setGeometry(QRect(70, 190, 211, 22));
        comboBox_arm_2->setEditable(false);
        comboBox_arm_3 = new QComboBox(groupBoxArm);
        comboBox_arm_3->addItem(QString());
        comboBox_arm_3->addItem(QString());
        comboBox_arm_3->addItem(QString());
        comboBox_arm_3->addItem(QString());
        comboBox_arm_3->addItem(QString());
        comboBox_arm_3->addItem(QString());
        comboBox_arm_3->addItem(QString());
        comboBox_arm_3->setObjectName(QString::fromUtf8("comboBox_arm_3"));
        comboBox_arm_3->setGeometry(QRect(70, 220, 211, 22));
        comboBox_arm_4 = new QComboBox(groupBoxArm);
        comboBox_arm_4->addItem(QString());
        comboBox_arm_4->addItem(QString());
        comboBox_arm_4->addItem(QString());
        comboBox_arm_4->addItem(QString());
        comboBox_arm_4->addItem(QString());
        comboBox_arm_4->addItem(QString());
        comboBox_arm_4->addItem(QString());
        comboBox_arm_4->setObjectName(QString::fromUtf8("comboBox_arm_4"));
        comboBox_arm_4->setGeometry(QRect(70, 250, 211, 22));
        comboBox_arm_5 = new QComboBox(groupBoxArm);
        comboBox_arm_5->addItem(QString());
        comboBox_arm_5->addItem(QString());
        comboBox_arm_5->addItem(QString());
        comboBox_arm_5->addItem(QString());
        comboBox_arm_5->addItem(QString());
        comboBox_arm_5->addItem(QString());
        comboBox_arm_5->addItem(QString());
        comboBox_arm_5->setObjectName(QString::fromUtf8("comboBox_arm_5"));
        comboBox_arm_5->setGeometry(QRect(70, 280, 211, 22));
        comboBox_arm_6 = new QComboBox(groupBoxArm);
        comboBox_arm_6->addItem(QString());
        comboBox_arm_6->addItem(QString());
        comboBox_arm_6->addItem(QString());
        comboBox_arm_6->addItem(QString());
        comboBox_arm_6->addItem(QString());
        comboBox_arm_6->addItem(QString());
        comboBox_arm_6->addItem(QString());
        comboBox_arm_6->setObjectName(QString::fromUtf8("comboBox_arm_6"));
        comboBox_arm_6->setGeometry(QRect(70, 310, 211, 22));
        label_Y_2 = new QLabel(groupBoxArm);
        label_Y_2->setObjectName(QString::fromUtf8("label_Y_2"));
        label_Y_2->setGeometry(QRect(10, 90, 41, 21));
        label_y_arm = new QLabel(groupBoxArm);
        label_y_arm->setObjectName(QString::fromUtf8("label_y_arm"));
        label_y_arm->setGeometry(QRect(230, 90, 49, 21));
        horizontalSlider_x_arm = new QSlider(groupBoxArm);
        horizontalSlider_x_arm->setObjectName(QString::fromUtf8("horizontalSlider_x_arm"));
        horizontalSlider_x_arm->setGeometry(QRect(60, 60, 160, 22));
        horizontalSlider_x_arm->setMinimum(-100);
        horizontalSlider_x_arm->setMaximum(100);
        horizontalSlider_x_arm->setSingleStep(0);
        horizontalSlider_x_arm->setPageStep(0);
        horizontalSlider_x_arm->setOrientation(Qt::Horizontal);
        label_x_arm = new QLabel(groupBoxArm);
        label_x_arm->setObjectName(QString::fromUtf8("label_x_arm"));
        label_x_arm->setGeometry(QRect(230, 60, 49, 21));
        spinBox_power_arm = new QSpinBox(groupBoxArm);
        spinBox_power_arm->setObjectName(QString::fromUtf8("spinBox_power_arm"));
        spinBox_power_arm->setGeometry(QRect(230, 30, 51, 22));
        spinBox_power_arm->setMaximum(100);
        label_POWER = new QLabel(groupBoxArm);
        label_POWER->setObjectName(QString::fromUtf8("label_POWER"));
        label_POWER->setGeometry(QRect(10, 30, 41, 21));
        horizontalSlider_power_arm = new QSlider(groupBoxArm);
        horizontalSlider_power_arm->setObjectName(QString::fromUtf8("horizontalSlider_power_arm"));
        horizontalSlider_power_arm->setGeometry(QRect(60, 30, 160, 22));
        horizontalSlider_power_arm->setStyleSheet(QString::fromUtf8(""));
        horizontalSlider_power_arm->setMaximum(100);
        horizontalSlider_power_arm->setOrientation(Qt::Horizontal);
        horizontalSlider_power_arm->setInvertedAppearance(false);
        horizontalSlider_power_arm->setInvertedControls(false);
        label_X_2 = new QLabel(groupBoxArm);
        label_X_2->setObjectName(QString::fromUtf8("label_X_2"));
        label_X_2->setGeometry(QRect(10, 60, 41, 21));
        horizontalSlider_y_arm = new QSlider(groupBoxArm);
        horizontalSlider_y_arm->setObjectName(QString::fromUtf8("horizontalSlider_y_arm"));
        horizontalSlider_y_arm->setGeometry(QRect(60, 90, 160, 22));
        horizontalSlider_y_arm->setAcceptDrops(false);
        horizontalSlider_y_arm->setMinimum(-100);
        horizontalSlider_y_arm->setMaximum(100);
        horizontalSlider_y_arm->setSingleStep(0);
        horizontalSlider_y_arm->setPageStep(0);
        horizontalSlider_y_arm->setOrientation(Qt::Horizontal);
        horizontalSlider_y_arm->setInvertedAppearance(false);
        horizontalSlider_y_arm->setInvertedControls(false);
        horizontalSlider_y_arm->setTickPosition(QSlider::NoTicks);
        horizontalSlider_y_arm->setTickInterval(0);
        pushButton_button_function_arm_1 = new QPushButton(groupBoxArm);
        pushButton_button_function_arm_1->setObjectName(QString::fromUtf8("pushButton_button_function_arm_1"));
        pushButton_button_function_arm_1->setGeometry(QRect(10, 161, 51, 20));
        QFont font;
        font.setPointSize(10);
        font.setBold(false);
        pushButton_button_function_arm_1->setFont(font);
        pushButton_button_function_arm_1->setStyleSheet(QString::fromUtf8(""));
        pushButton_button_function_arm_1->setCheckable(false);
        pushButton_button_function_arm_2 = new QPushButton(groupBoxArm);
        pushButton_button_function_arm_2->setObjectName(QString::fromUtf8("pushButton_button_function_arm_2"));
        pushButton_button_function_arm_2->setGeometry(QRect(10, 190, 51, 21));
        pushButton_button_function_arm_2->setFont(font);
        pushButton_button_function_arm_2->setStyleSheet(QString::fromUtf8(""));
        pushButton_button_function_arm_3 = new QPushButton(groupBoxArm);
        pushButton_button_function_arm_3->setObjectName(QString::fromUtf8("pushButton_button_function_arm_3"));
        pushButton_button_function_arm_3->setGeometry(QRect(10, 220, 51, 21));
        pushButton_button_function_arm_3->setFont(font);
        pushButton_button_function_arm_3->setStyleSheet(QString::fromUtf8(""));
        pushButton_button_function_arm_4 = new QPushButton(groupBoxArm);
        pushButton_button_function_arm_4->setObjectName(QString::fromUtf8("pushButton_button_function_arm_4"));
        pushButton_button_function_arm_4->setGeometry(QRect(10, 250, 51, 21));
        pushButton_button_function_arm_4->setFont(font);
        pushButton_button_function_arm_4->setStyleSheet(QString::fromUtf8(""));
        pushButton_button_function_arm_5 = new QPushButton(groupBoxArm);
        pushButton_button_function_arm_5->setObjectName(QString::fromUtf8("pushButton_button_function_arm_5"));
        pushButton_button_function_arm_5->setGeometry(QRect(10, 280, 51, 21));
        pushButton_button_function_arm_5->setFont(font);
        pushButton_button_function_arm_5->setStyleSheet(QString::fromUtf8(""));
        pushButton_button_function_arm_6 = new QPushButton(groupBoxArm);
        pushButton_button_function_arm_6->setObjectName(QString::fromUtf8("pushButton_button_function_arm_6"));
        pushButton_button_function_arm_6->setGeometry(QRect(10, 310, 51, 21));
        pushButton_button_function_arm_6->setFont(font);
        pushButton_button_function_arm_6->setStyleSheet(QString::fromUtf8(""));
        progressBar_motor_base = new QProgressBar(groupBoxArm);
        progressBar_motor_base->setObjectName(QString::fromUtf8("progressBar_motor_base"));
        progressBar_motor_base->setGeometry(QRect(330, 315, 135, 25));
        progressBar_motor_base->setLayoutDirection(Qt::LeftToRight);
        progressBar_motor_base->setAutoFillBackground(false);
        progressBar_motor_base->setStyleSheet(QString::fromUtf8("QProgressBar {\n"
"    border: 1px solid grey;\n"
"    background-color: rgb(51, 153, 255);\n"
"}\n"
"QProgressBar::chunk {\n"
"    background-color: rgb(255, 255, 102);\n"
"    width: 1px;\n"
"}\n"
""));
        progressBar_motor_base->setMinimum(0);
        progressBar_motor_base->setMaximum(6400);
        progressBar_motor_base->setValue(3200);
        progressBar_motor_base->setTextVisible(false);
        progressBar_motor_base->setOrientation(Qt::Horizontal);
        progressBar_motor_base->setInvertedAppearance(false);
        progressBar_motor_base->setTextDirection(QProgressBar::TopToBottom);
        progressBar_motor_first = new QProgressBar(groupBoxArm);
        progressBar_motor_first->setObjectName(QString::fromUtf8("progressBar_motor_first"));
        progressBar_motor_first->setGeometry(QRect(330, 260, 135, 25));
        progressBar_motor_first->setLayoutDirection(Qt::LeftToRight);
        progressBar_motor_first->setAutoFillBackground(false);
        progressBar_motor_first->setStyleSheet(QString::fromUtf8("QProgressBar {\n"
"    border: 1px solid grey;\n"
"    background-color: rgb(51, 153, 255);\n"
"}\n"
"QProgressBar::chunk {\n"
"    background-color: rgb(255, 255, 102);\n"
"    width: 1px;\n"
"}\n"
""));
        progressBar_motor_first->setMinimum(0);
        progressBar_motor_first->setMaximum(6400);
        progressBar_motor_first->setValue(3200);
        progressBar_motor_first->setTextVisible(false);
        progressBar_motor_first->setOrientation(Qt::Horizontal);
        progressBar_motor_first->setInvertedAppearance(false);
        progressBar_motor_first->setTextDirection(QProgressBar::TopToBottom);
        progressBar_motor_second = new QProgressBar(groupBoxArm);
        progressBar_motor_second->setObjectName(QString::fromUtf8("progressBar_motor_second"));
        progressBar_motor_second->setGeometry(QRect(330, 205, 135, 25));
        progressBar_motor_second->setLayoutDirection(Qt::LeftToRight);
        progressBar_motor_second->setAutoFillBackground(false);
        progressBar_motor_second->setStyleSheet(QString::fromUtf8("QProgressBar {\n"
"    border: 1px solid grey;\n"
"    background-color: rgb(51, 153, 255);\n"
"}\n"
"QProgressBar::chunk {\n"
"    background-color: rgb(255, 255, 102);\n"
"    width: 1px;\n"
"}\n"
""));
        progressBar_motor_second->setMinimum(0);
        progressBar_motor_second->setMaximum(6400);
        progressBar_motor_second->setValue(3200);
        progressBar_motor_second->setTextVisible(false);
        progressBar_motor_second->setOrientation(Qt::Horizontal);
        progressBar_motor_second->setInvertedAppearance(false);
        progressBar_motor_second->setTextDirection(QProgressBar::TopToBottom);
        progressBar_motor_third = new QProgressBar(groupBoxArm);
        progressBar_motor_third->setObjectName(QString::fromUtf8("progressBar_motor_third"));
        progressBar_motor_third->setGeometry(QRect(330, 150, 135, 25));
        progressBar_motor_third->setLayoutDirection(Qt::LeftToRight);
        progressBar_motor_third->setAutoFillBackground(false);
        progressBar_motor_third->setStyleSheet(QString::fromUtf8("QProgressBar {\n"
"    border: 1px solid grey;\n"
"    background-color: rgb(51, 153, 255);\n"
"}\n"
"QProgressBar::chunk {\n"
"    background-color: rgb(255, 255, 102);\n"
"    width: 1px;\n"
"}\n"
""));
        progressBar_motor_third->setMinimum(0);
        progressBar_motor_third->setMaximum(6400);
        progressBar_motor_third->setValue(3200);
        progressBar_motor_third->setTextVisible(false);
        progressBar_motor_third->setOrientation(Qt::Horizontal);
        progressBar_motor_third->setInvertedAppearance(false);
        progressBar_motor_third->setTextDirection(QProgressBar::TopToBottom);
        progressBar_motor_jaws = new QProgressBar(groupBoxArm);
        progressBar_motor_jaws->setObjectName(QString::fromUtf8("progressBar_motor_jaws"));
        progressBar_motor_jaws->setGeometry(QRect(330, 95, 135, 25));
        progressBar_motor_jaws->setLayoutDirection(Qt::LeftToRight);
        progressBar_motor_jaws->setAutoFillBackground(false);
        progressBar_motor_jaws->setStyleSheet(QString::fromUtf8("QProgressBar {\n"
"    border: 1px solid grey;\n"
"    background-color: rgb(51, 153, 255);\n"
"}\n"
"QProgressBar::chunk {\n"
"    background-color: rgb(255, 255, 102);\n"
"    width: 1px;\n"
"}\n"
""));
        progressBar_motor_jaws->setMinimum(0);
        progressBar_motor_jaws->setMaximum(6400);
        progressBar_motor_jaws->setValue(3200);
        progressBar_motor_jaws->setTextVisible(false);
        progressBar_motor_jaws->setOrientation(Qt::Horizontal);
        progressBar_motor_jaws->setInvertedAppearance(false);
        progressBar_motor_jaws->setTextDirection(QProgressBar::TopToBottom);
        progressBar_motor_jaws_clench = new QProgressBar(groupBoxArm);
        progressBar_motor_jaws_clench->setObjectName(QString::fromUtf8("progressBar_motor_jaws_clench"));
        progressBar_motor_jaws_clench->setGeometry(QRect(330, 40, 135, 25));
        progressBar_motor_jaws_clench->setLayoutDirection(Qt::LeftToRight);
        progressBar_motor_jaws_clench->setAutoFillBackground(false);
        progressBar_motor_jaws_clench->setStyleSheet(QString::fromUtf8("QProgressBar {\n"
"    border: 1px solid grey;\n"
"    background-color: rgb(51, 153, 255);\n"
"}\n"
"QProgressBar::chunk {\n"
"    background-color: rgb(255, 255, 102);\n"
"    width: 1px;\n"
"}\n"
""));
        progressBar_motor_jaws_clench->setMinimum(0);
        progressBar_motor_jaws_clench->setMaximum(6400);
        progressBar_motor_jaws_clench->setValue(3200);
        progressBar_motor_jaws_clench->setTextVisible(false);
        progressBar_motor_jaws_clench->setOrientation(Qt::Horizontal);
        progressBar_motor_jaws_clench->setInvertedAppearance(false);
        progressBar_motor_jaws_clench->setTextDirection(QProgressBar::TopToBottom);
        label_motor_base = new QLabel(groupBoxArm);
        label_motor_base->setObjectName(QString::fromUtf8("label_motor_base"));
        label_motor_base->setGeometry(QRect(330, 290, 135, 20));
        label_motor_base->setAlignment(Qt::AlignCenter);
        label_motor_first = new QLabel(groupBoxArm);
        label_motor_first->setObjectName(QString::fromUtf8("label_motor_first"));
        label_motor_first->setGeometry(QRect(330, 235, 135, 20));
        label_motor_first->setAlignment(Qt::AlignCenter);
        label_motor_second = new QLabel(groupBoxArm);
        label_motor_second->setObjectName(QString::fromUtf8("label_motor_second"));
        label_motor_second->setGeometry(QRect(330, 180, 135, 20));
        label_motor_second->setAlignment(Qt::AlignCenter);
        label_motor_third = new QLabel(groupBoxArm);
        label_motor_third->setObjectName(QString::fromUtf8("label_motor_third"));
        label_motor_third->setGeometry(QRect(330, 125, 135, 20));
        label_motor_third->setAlignment(Qt::AlignCenter);
        label_motor_jaws = new QLabel(groupBoxArm);
        label_motor_jaws->setObjectName(QString::fromUtf8("label_motor_jaws"));
        label_motor_jaws->setGeometry(QRect(330, 70, 135, 20));
        label_motor_jaws->setAlignment(Qt::AlignCenter);
        label_motor_jaws_clench = new QLabel(groupBoxArm);
        label_motor_jaws_clench->setObjectName(QString::fromUtf8("label_motor_jaws_clench"));
        label_motor_jaws_clench->setGeometry(QRect(330, 15, 135, 20));
        label_motor_jaws_clench->setAlignment(Qt::AlignCenter);
        groupBoxDrive = new QGroupBox(centralwidget);
        groupBoxDrive->setObjectName(QString::fromUtf8("groupBoxDrive"));
        groupBoxDrive->setGeometry(QRect(8, 364, 511, 413));
        groupBoxDrive->setStyleSheet(QString::fromUtf8(""));
        label_Y = new QLabel(groupBoxDrive);
        label_Y->setObjectName(QString::fromUtf8("label_Y"));
        label_Y->setGeometry(QRect(10, 90, 41, 21));
        label_y_drive = new QLabel(groupBoxDrive);
        label_y_drive->setObjectName(QString::fromUtf8("label_y_drive"));
        label_y_drive->setGeometry(QRect(238, 90, 41, 21));
        horizontalSlider_x_drive = new QSlider(groupBoxDrive);
        horizontalSlider_x_drive->setObjectName(QString::fromUtf8("horizontalSlider_x_drive"));
        horizontalSlider_x_drive->setEnabled(true);
        horizontalSlider_x_drive->setGeometry(QRect(60, 60, 169, 22));
        horizontalSlider_x_drive->setMinimum(-100);
        horizontalSlider_x_drive->setMaximum(100);
        horizontalSlider_x_drive->setSingleStep(0);
        horizontalSlider_x_drive->setPageStep(0);
        horizontalSlider_x_drive->setOrientation(Qt::Horizontal);
        horizontalSlider_power_drive = new QSlider(groupBoxDrive);
        horizontalSlider_power_drive->setObjectName(QString::fromUtf8("horizontalSlider_power_drive"));
        horizontalSlider_power_drive->setGeometry(QRect(60, 30, 169, 22));
        horizontalSlider_power_drive->setMaximum(100);
        horizontalSlider_power_drive->setOrientation(Qt::Horizontal);
        horizontalSlider_power_drive->setInvertedAppearance(false);
        horizontalSlider_power_drive->setInvertedControls(false);
        label_X = new QLabel(groupBoxDrive);
        label_X->setObjectName(QString::fromUtf8("label_X"));
        label_X->setGeometry(QRect(10, 60, 41, 21));
        label_power_drive = new QLabel(groupBoxDrive);
        label_power_drive->setObjectName(QString::fromUtf8("label_power_drive"));
        label_power_drive->setGeometry(QRect(10, 30, 41, 21));
        label_x_drive = new QLabel(groupBoxDrive);
        label_x_drive->setObjectName(QString::fromUtf8("label_x_drive"));
        label_x_drive->setGeometry(QRect(238, 60, 41, 21));
        horizontalSlider_y_drive = new QSlider(groupBoxDrive);
        horizontalSlider_y_drive->setObjectName(QString::fromUtf8("horizontalSlider_y_drive"));
        horizontalSlider_y_drive->setGeometry(QRect(60, 90, 169, 22));
        horizontalSlider_y_drive->setAcceptDrops(false);
        horizontalSlider_y_drive->setMinimum(-100);
        horizontalSlider_y_drive->setMaximum(100);
        horizontalSlider_y_drive->setSingleStep(0);
        horizontalSlider_y_drive->setPageStep(0);
        horizontalSlider_y_drive->setOrientation(Qt::Horizontal);
        horizontalSlider_y_drive->setInvertedAppearance(false);
        horizontalSlider_y_drive->setInvertedControls(false);
        horizontalSlider_y_drive->setTickPosition(QSlider::NoTicks);
        horizontalSlider_y_drive->setTickInterval(0);
        spinBox_power_drive = new QSpinBox(groupBoxDrive);
        spinBox_power_drive->setObjectName(QString::fromUtf8("spinBox_power_drive"));
        spinBox_power_drive->setGeometry(QRect(236, 30, 45, 22));
        spinBox_power_drive->setMaximum(100);
        progressBar_wheel_left_back = new QProgressBar(groupBoxDrive);
        progressBar_wheel_left_back->setObjectName(QString::fromUtf8("progressBar_wheel_left_back"));
        progressBar_wheel_left_back->setGeometry(QRect(315, 280, 20, 120));
        progressBar_wheel_left_back->setLayoutDirection(Qt::LeftToRight);
        progressBar_wheel_left_back->setAutoFillBackground(false);
        progressBar_wheel_left_back->setStyleSheet(QString::fromUtf8("QProgressBar {\n"
"        border: 1px solid grey;\n"
"        background-color: rgba(235, 0, 0, 150);\n"
"    }\n"
"    QProgressBar::chunk {\n"
"        background-color: green;\n"
"		height: 1px;\n"
"    }"));
        progressBar_wheel_left_back->setMaximum(6400);
        progressBar_wheel_left_back->setValue(3200);
        progressBar_wheel_left_back->setTextVisible(false);
        progressBar_wheel_left_back->setOrientation(Qt::Vertical);
        progressBar_wheel_left_back->setInvertedAppearance(false);
        progressBar_wheel_left_back->setTextDirection(QProgressBar::TopToBottom);
        progressBar_wheel_left_middle = new QProgressBar(groupBoxDrive);
        progressBar_wheel_left_middle->setObjectName(QString::fromUtf8("progressBar_wheel_left_middle"));
        progressBar_wheel_left_middle->setGeometry(QRect(315, 152, 20, 120));
        progressBar_wheel_left_middle->setLayoutDirection(Qt::LeftToRight);
        progressBar_wheel_left_middle->setAutoFillBackground(false);
        progressBar_wheel_left_middle->setStyleSheet(QString::fromUtf8("QProgressBar {\n"
"        border: 1px solid grey;\n"
"        background-color: rgba(235, 0, 0, 150);\n"
"    }\n"
"    QProgressBar::chunk {\n"
"        background-color: green;\n"
"		height: 1px;\n"
"    }"));
        progressBar_wheel_left_middle->setMaximum(6400);
        progressBar_wheel_left_middle->setValue(3200);
        progressBar_wheel_left_middle->setTextVisible(false);
        progressBar_wheel_left_middle->setOrientation(Qt::Vertical);
        progressBar_wheel_left_middle->setInvertedAppearance(false);
        progressBar_wheel_left_middle->setTextDirection(QProgressBar::TopToBottom);
        progressBar_wheel_left_front = new QProgressBar(groupBoxDrive);
        progressBar_wheel_left_front->setObjectName(QString::fromUtf8("progressBar_wheel_left_front"));
        progressBar_wheel_left_front->setGeometry(QRect(315, 24, 20, 120));
        progressBar_wheel_left_front->setLayoutDirection(Qt::LeftToRight);
        progressBar_wheel_left_front->setAutoFillBackground(false);
        progressBar_wheel_left_front->setStyleSheet(QString::fromUtf8("QProgressBar {\n"
"        border: 1px solid grey;\n"
"        background-color: rgba(235, 0, 0, 150);\n"
"    }\n"
"    QProgressBar::chunk {\n"
"        background-color: green;\n"
"		height: 1px;\n"
"    }"));
        progressBar_wheel_left_front->setMinimum(0);
        progressBar_wheel_left_front->setMaximum(6400);
        progressBar_wheel_left_front->setValue(3200);
        progressBar_wheel_left_front->setTextVisible(false);
        progressBar_wheel_left_front->setOrientation(Qt::Vertical);
        progressBar_wheel_left_front->setInvertedAppearance(false);
        progressBar_wheel_left_front->setTextDirection(QProgressBar::TopToBottom);
        progressBar_wheel_right_back = new QProgressBar(groupBoxDrive);
        progressBar_wheel_right_back->setObjectName(QString::fromUtf8("progressBar_wheel_right_back"));
        progressBar_wheel_right_back->setGeometry(QRect(465, 280, 20, 120));
        progressBar_wheel_right_back->setLayoutDirection(Qt::LeftToRight);
        progressBar_wheel_right_back->setAutoFillBackground(false);
        progressBar_wheel_right_back->setStyleSheet(QString::fromUtf8("QProgressBar {\n"
"        border: 1px solid grey;\n"
"        background-color: rgba(235, 0, 0, 150);\n"
"    }\n"
"    QProgressBar::chunk {\n"
"        background-color: green;\n"
"		height: 1px;\n"
"    }"));
        progressBar_wheel_right_back->setMaximum(6400);
        progressBar_wheel_right_back->setValue(3200);
        progressBar_wheel_right_back->setTextVisible(false);
        progressBar_wheel_right_back->setOrientation(Qt::Vertical);
        progressBar_wheel_right_back->setInvertedAppearance(false);
        progressBar_wheel_right_back->setTextDirection(QProgressBar::TopToBottom);
        progressBar_wheel_right_front = new QProgressBar(groupBoxDrive);
        progressBar_wheel_right_front->setObjectName(QString::fromUtf8("progressBar_wheel_right_front"));
        progressBar_wheel_right_front->setGeometry(QRect(465, 24, 20, 120));
        progressBar_wheel_right_front->setLayoutDirection(Qt::LeftToRight);
        progressBar_wheel_right_front->setAutoFillBackground(false);
        progressBar_wheel_right_front->setStyleSheet(QString::fromUtf8("QProgressBar {\n"
"        border: 1px solid grey;\n"
"        background-color: rgba(235, 0, 0, 150);\n"
"    }\n"
"    QProgressBar::chunk {\n"
"        background-color: green;\n"
"		height: 1px;\n"
"    }"));
        progressBar_wheel_right_front->setMaximum(6400);
        progressBar_wheel_right_front->setValue(3200);
        progressBar_wheel_right_front->setTextVisible(false);
        progressBar_wheel_right_front->setOrientation(Qt::Vertical);
        progressBar_wheel_right_front->setInvertedAppearance(false);
        progressBar_wheel_right_front->setTextDirection(QProgressBar::TopToBottom);
        progressBar_wheel_right_middle = new QProgressBar(groupBoxDrive);
        progressBar_wheel_right_middle->setObjectName(QString::fromUtf8("progressBar_wheel_right_middle"));
        progressBar_wheel_right_middle->setGeometry(QRect(465, 152, 20, 120));
        progressBar_wheel_right_middle->setLayoutDirection(Qt::LeftToRight);
        progressBar_wheel_right_middle->setAutoFillBackground(false);
        progressBar_wheel_right_middle->setStyleSheet(QString::fromUtf8("QProgressBar {\n"
"        border: 1px solid grey;\n"
"        background-color: rgba(235, 0, 0, 150);\n"
"    }\n"
"    QProgressBar::chunk {\n"
"        background-color: green;\n"
"		height: 1px;\n"
"    }"));
        progressBar_wheel_right_middle->setMaximum(6400);
        progressBar_wheel_right_middle->setValue(3200);
        progressBar_wheel_right_middle->setTextVisible(false);
        progressBar_wheel_right_middle->setOrientation(Qt::Vertical);
        progressBar_wheel_right_middle->setInvertedAppearance(false);
        progressBar_wheel_right_middle->setTextDirection(QProgressBar::TopToBottom);
        groupBox_4 = new QGroupBox(centralwidget);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setGeometry(QRect(838, 4, 693, 773));
        groupBox_4->setStyleSheet(QString::fromUtf8(""));
        graphicsView = new QGraphicsView(groupBox_4);
        graphicsView->setObjectName(QString::fromUtf8("graphicsView"));
        graphicsView->setGeometry(QRect(12, 24, 669, 437));
        groupBox_7 = new QGroupBox(groupBox_4);
        groupBox_7->setObjectName(QString::fromUtf8("groupBox_7"));
        groupBox_7->setGeometry(QRect(12, 472, 669, 283));
        tableWidget_nav = new QTableWidget(groupBox_7);
        if (tableWidget_nav->columnCount() < 3)
            tableWidget_nav->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget_nav->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget_nav->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget_nav->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        tableWidget_nav->setObjectName(QString::fromUtf8("tableWidget_nav"));
        tableWidget_nav->setGeometry(QRect(6, 24, 377, 173));
        tableWidget_nav->setMaximumSize(QSize(500, 16777215));
        tableWidget_nav->setLayoutDirection(Qt::LeftToRight);
        tableWidget_nav->setAutoFillBackground(false);
        tableWidget_nav->setStyleSheet(QString::fromUtf8(""));
        tableWidget_nav->setLocale(QLocale(QLocale::Polish, QLocale::Poland));
        tableWidget_nav->setAutoScroll(true);
        tableWidget_nav->setDragEnabled(false);
        tableWidget_nav->setSortingEnabled(true);
        label_18 = new QLabel(groupBox_7);
        label_18->setObjectName(QString::fromUtf8("label_18"));
        label_18->setGeometry(QRect(9, 212, 79, 21));
        label_19 = new QLabel(groupBox_7);
        label_19->setObjectName(QString::fromUtf8("label_19"));
        label_19->setGeometry(QRect(9, 242, 79, 21));
        pushButton_add_pos = new QPushButton(groupBox_7);
        pushButton_add_pos->setObjectName(QString::fromUtf8("pushButton_add_pos"));
        pushButton_add_pos->setGeometry(QRect(204, 210, 87, 25));
        label_22 = new QLabel(groupBox_7);
        label_22->setObjectName(QString::fromUtf8("label_22"));
        label_22->setGeometry(QRect(302, 212, 81, 16));
        labelChoosenIndex = new QLabel(groupBox_7);
        labelChoosenIndex->setObjectName(QString::fromUtf8("labelChoosenIndex"));
        labelChoosenIndex->setGeometry(QRect(302, 240, 83, 16));
        pushButtonDeletePoint = new QPushButton(groupBox_7);
        pushButtonDeletePoint->setObjectName(QString::fromUtf8("pushButtonDeletePoint"));
        pushButtonDeletePoint->setGeometry(QRect(204, 240, 87, 27));
        lineEditPosX = new QLineEdit(groupBox_7);
        lineEditPosX->setObjectName(QString::fromUtf8("lineEditPosX"));
        lineEditPosX->setGeometry(QRect(94, 212, 101, 22));
        lineEditPosY = new QLineEdit(groupBox_7);
        lineEditPosY->setObjectName(QString::fromUtf8("lineEditPosY"));
        lineEditPosY->setGeometry(QRect(94, 244, 101, 22));
        pushButtonUnZoom = new QPushButton(groupBox_7);
        pushButtonUnZoom->setObjectName(QString::fromUtf8("pushButtonUnZoom"));
        pushButtonUnZoom->setGeometry(QRect(562, 16, 41, 24));
        pushButtonZoom = new QPushButton(groupBox_7);
        pushButtonZoom->setObjectName(QString::fromUtf8("pushButtonZoom"));
        pushButtonZoom->setGeometry(QRect(606, 16, 41, 24));
        label_scale = new QLabel(groupBox_7);
        label_scale->setObjectName(QString::fromUtf8("label_scale"));
        label_scale->setGeometry(QRect(564, 44, 83, 20));
        label_scale->setAlignment(Qt::AlignCenter);
        pushButtonRotate = new QPushButton(groupBox_7);
        pushButtonRotate->setObjectName(QString::fromUtf8("pushButtonRotate"));
        pushButtonRotate->setEnabled(false);
        pushButtonRotate->setGeometry(QRect(454, 206, 151, 24));
        lineEditPosXRover = new QLineEdit(groupBox_7);
        lineEditPosXRover->setObjectName(QString::fromUtf8("lineEditPosXRover"));
        lineEditPosXRover->setGeometry(QRect(426, 96, 199, 22));
        lineEditPosYRover = new QLineEdit(groupBox_7);
        lineEditPosYRover->setObjectName(QString::fromUtf8("lineEditPosYRover"));
        lineEditPosYRover->setGeometry(QRect(426, 124, 199, 22));
        lineEditRotate = new QLineEdit(groupBox_7);
        lineEditRotate->setObjectName(QString::fromUtf8("lineEditRotate"));
        lineEditRotate->setGeometry(QRect(482, 180, 91, 22));
        pushButtonSend = new QPushButton(groupBox_7);
        pushButtonSend->setObjectName(QString::fromUtf8("pushButtonSend"));
        pushButtonSend->setEnabled(true);
        pushButtonSend->setGeometry(QRect(452, 150, 151, 24));
        pushButton = new QPushButton(groupBox_7);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(454, 234, 153, 43));
        groupBox_2 = new QGroupBox(centralwidget);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(528, 126, 301, 227));
        label_drive_control = new QLabel(groupBox_2);
        label_drive_control->setObjectName(QString::fromUtf8("label_drive_control"));
        label_drive_control->setGeometry(QRect(25, 186, 51, 20));
        label_arm_control = new QLabel(groupBox_2);
        label_arm_control->setObjectName(QString::fromUtf8("label_arm_control"));
        label_arm_control->setGeometry(QRect(25, 156, 31, 20));
        label_arm_control->setFrameShape(QFrame::NoFrame);
        comboBox_arm_control = new QComboBox(groupBox_2);
        comboBox_arm_control->addItem(QString());
        comboBox_arm_control->addItem(QString());
        comboBox_arm_control->addItem(QString());
        comboBox_arm_control->setObjectName(QString::fromUtf8("comboBox_arm_control"));
        comboBox_arm_control->setGeometry(QRect(125, 156, 151, 26));
        comboBox_arm_control->setMaxVisibleItems(5);
        comboBox_drive_control = new QComboBox(groupBox_2);
        comboBox_drive_control->addItem(QString());
        comboBox_drive_control->addItem(QString());
        comboBox_drive_control->addItem(QString());
        comboBox_drive_control->setObjectName(QString::fromUtf8("comboBox_drive_control"));
        comboBox_drive_control->setGeometry(QRect(125, 186, 151, 26));
        comboBox_drive_control->setMaxVisibleItems(5);
        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(25, 96, 81, 20));
        label_4 = new QLabel(groupBox_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(25, 126, 81, 21));
        lineEdit_IP_adress = new QLineEdit(groupBox_2);
        lineEdit_IP_adress->setObjectName(QString::fromUtf8("lineEdit_IP_adress"));
        lineEdit_IP_adress->setGeometry(QRect(125, 96, 151, 26));
        lineEdit_port = new QLineEdit(groupBox_2);
        lineEdit_port->setObjectName(QString::fromUtf8("lineEdit_port"));
        lineEdit_port->setGeometry(QRect(125, 126, 151, 26));
        pushButton_stop = new QPushButton(groupBox_2);
        pushButton_stop->setObjectName(QString::fromUtf8("pushButton_stop"));
        pushButton_stop->setGeometry(QRect(20, 30, 261, 51));
        pushButton_stop->setStyleSheet(QString::fromUtf8("\n"
"  background: rgb(156, 18, 18);\n"
"  \n"
"\n"
"\n"
""));
        pushButton_stop->setCheckable(false);
        pushButton_stop->setAutoDefault(false);
        pushButton_stop->setFlat(false);
        groupBox_8 = new QGroupBox(centralwidget);
        groupBox_8->setObjectName(QString::fromUtf8("groupBox_8"));
        groupBox_8->setGeometry(QRect(530, 360, 297, 125));
        label_frames_received_count = new QLabel(groupBox_8);
        label_frames_received_count->setObjectName(QString::fromUtf8("label_frames_received_count"));
        label_frames_received_count->setGeometry(QRect(140, 50, 131, 20));
        label_frames_sent_count = new QLabel(groupBox_8);
        label_frames_sent_count->setObjectName(QString::fromUtf8("label_frames_sent_count"));
        label_frames_sent_count->setGeometry(QRect(140, 30, 131, 20));
        label_frames_sent_count->setStyleSheet(QString::fromUtf8(""));
        label = new QLabel(groupBox_8);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 30, 91, 20));
        label->setStyleSheet(QString::fromUtf8(""));
        label_8 = new QLabel(groupBox_8);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(20, 50, 111, 20));
        label_10 = new QLabel(groupBox_8);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(20, 90, 111, 20));
        label_current_ip = new QLabel(groupBox_8);
        label_current_ip->setObjectName(QString::fromUtf8("label_current_ip"));
        label_current_ip->setGeometry(QRect(140, 90, 125, 20));
        label_2 = new QLabel(groupBox_8);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 70, 111, 20));
        label_joysticks_count = new QLabel(groupBox_8);
        label_joysticks_count->setObjectName(QString::fromUtf8("label_joysticks_count"));
        label_joysticks_count->setGeometry(QRect(140, 70, 16, 20));
        groupBox = new QGroupBox(centralwidget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(526, 492, 301, 73));
        textBrowser_printer = new QTextBrowser(groupBox);
        textBrowser_printer->setObjectName(QString::fromUtf8("textBrowser_printer"));
        textBrowser_printer->setGeometry(QRect(4, 22, 295, 47));
        textBrowser_printer->setFrameShape(QFrame::NoFrame);
        textBrowser_printer->setFrameShadow(QFrame::Plain);
        textBrowser_printer->setLineWidth(1);
        textBrowser_printer->setMidLineWidth(0);
        groupBox_3 = new QGroupBox(centralwidget);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(530, 12, 301, 107));
        horizontalSliderPokerAngle = new QSlider(groupBox_3);
        horizontalSliderPokerAngle->setObjectName(QString::fromUtf8("horizontalSliderPokerAngle"));
        horizontalSliderPokerAngle->setGeometry(QRect(60, 26, 165, 18));
        horizontalSliderPokerAngle->setMinimum(0);
        horizontalSliderPokerAngle->setMaximum(180);
        horizontalSliderPokerAngle->setSingleStep(1);
        horizontalSliderPokerAngle->setPageStep(1);
        horizontalSliderPokerAngle->setValue(130);
        horizontalSliderPokerAngle->setOrientation(Qt::Horizontal);
        horizontalSliderPokerAngle->setInvertedAppearance(false);
        horizontalSliderPokerPoke = new QSlider(groupBox_3);
        horizontalSliderPokerPoke->setObjectName(QString::fromUtf8("horizontalSliderPokerPoke"));
        horizontalSliderPokerPoke->setGeometry(QRect(60, 62, 165, 18));
        horizontalSliderPokerPoke->setMaximum(180);
        horizontalSliderPokerPoke->setSingleStep(180);
        horizontalSliderPokerPoke->setPageStep(30);
        horizontalSliderPokerPoke->setOrientation(Qt::Horizontal);
        label_5 = new QLabel(groupBox_3);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(16, 24, 45, 20));
        label_6 = new QLabel(groupBox_3);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(18, 60, 35, 20));
        spinBoxPokerAngle = new QSpinBox(groupBox_3);
        spinBoxPokerAngle->setObjectName(QString::fromUtf8("spinBoxPokerAngle"));
        spinBoxPokerAngle->setGeometry(QRect(232, 22, 63, 29));
        spinBoxPokerAngle->setMaximum(180);
        spinBoxPokerAngle->setValue(130);
        spinBoxPokerPoke = new QSpinBox(groupBox_3);
        spinBoxPokerPoke->setObjectName(QString::fromUtf8("spinBoxPokerPoke"));
        spinBoxPokerPoke->setGeometry(QRect(232, 56, 63, 29));
        spinBoxPokerPoke->setMaximum(180);
        groupBox_5 = new QGroupBox(centralwidget);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        groupBox_5->setGeometry(QRect(524, 570, 305, 203));
        label_science_revolver_value = new QLabel(groupBox_5);
        label_science_revolver_value->setObjectName(QString::fromUtf8("label_science_revolver_value"));
        label_science_revolver_value->setGeometry(QRect(130, 86, 33, 21));
        label_science_revolver_value->setAlignment(Qt::AlignCenter);
        checkBox_lid_1 = new QCheckBox(groupBox_5);
        checkBox_lid_1->setObjectName(QString::fromUtf8("checkBox_lid_1"));
        checkBox_lid_1->setGeometry(QRect(-22, 42, 105, 19));
        checkBox_lid_1->setLayoutDirection(Qt::RightToLeft);
        checkBox_lid_2 = new QCheckBox(groupBox_5);
        checkBox_lid_2->setObjectName(QString::fromUtf8("checkBox_lid_2"));
        checkBox_lid_2->setGeometry(QRect(-22, 64, 105, 19));
        checkBox_lid_2->setLayoutDirection(Qt::RightToLeft);
        checkBox_lid_3 = new QCheckBox(groupBox_5);
        checkBox_lid_3->setObjectName(QString::fromUtf8("checkBox_lid_3"));
        checkBox_lid_3->setGeometry(QRect(-22, 88, 105, 19));
        checkBox_lid_3->setLayoutDirection(Qt::RightToLeft);
        checkBox_lid_4 = new QCheckBox(groupBox_5);
        checkBox_lid_4->setObjectName(QString::fromUtf8("checkBox_lid_4"));
        checkBox_lid_4->setGeometry(QRect(-22, 112, 105, 19));
        checkBox_lid_4->setLayoutDirection(Qt::RightToLeft);
        checkBox_pump_3 = new QCheckBox(groupBox_5);
        checkBox_pump_3->setObjectName(QString::fromUtf8("checkBox_pump_3"));
        checkBox_pump_3->setGeometry(QRect(204, 88, 105, 19));
        checkBox_pump_4 = new QCheckBox(groupBox_5);
        checkBox_pump_4->setObjectName(QString::fromUtf8("checkBox_pump_4"));
        checkBox_pump_4->setGeometry(QRect(204, 112, 105, 19));
        checkBox_pump_1 = new QCheckBox(groupBox_5);
        checkBox_pump_1->setObjectName(QString::fromUtf8("checkBox_pump_1"));
        checkBox_pump_1->setGeometry(QRect(204, 42, 105, 19));
        checkBox_pump_2 = new QCheckBox(groupBox_5);
        checkBox_pump_2->setObjectName(QString::fromUtf8("checkBox_pump_2"));
        checkBox_pump_2->setGeometry(QRect(204, 64, 105, 19));
        label_science_revolver_name = new QLabel(groupBox_5);
        label_science_revolver_name->setObjectName(QString::fromUtf8("label_science_revolver_name"));
        label_science_revolver_name->setGeometry(QRect(114, 18, 65, 20));
        pushButton_revolver_plus = new QPushButton(groupBox_5);
        pushButton_revolver_plus->setObjectName(QString::fromUtf8("pushButton_revolver_plus"));
        pushButton_revolver_plus->setGeometry(QRect(154, 46, 39, 37));
        pushButton_revolver_minus = new QPushButton(groupBox_5);
        pushButton_revolver_minus->setObjectName(QString::fromUtf8("pushButton_revolver_minus"));
        pushButton_revolver_minus->setGeometry(QRect(98, 46, 39, 37));
        dial_revolver = new QDial(groupBox_5);
        dial_revolver->setObjectName(QString::fromUtf8("dial_revolver"));
        dial_revolver->setEnabled(false);
        dial_revolver->setGeometry(QRect(100, 102, 93, 103));
        dial_revolver->setMaximum(360);
        dial_revolver->setSingleStep(1);
        dial_revolver->setPageStep(1);
        dial_revolver->setWrapping(true);
        dial_revolver->setNotchTarget(45.000000000000000);
        dial_revolver->setNotchesVisible(true);
        MainWindow->setCentralWidget(centralwidget);
        groupBox_5->raise();
        groupBoxArm->raise();
        groupBoxDrive->raise();
        groupBox_4->raise();
        groupBox_2->raise();
        groupBox_8->raise();
        groupBox->raise();
        groupBox_3->raise();

        retranslateUi(MainWindow);

        comboBox_arm_1->setCurrentIndex(1);
        comboBox_arm_2->setCurrentIndex(2);
        comboBox_arm_3->setCurrentIndex(3);
        comboBox_arm_4->setCurrentIndex(4);
        comboBox_arm_5->setCurrentIndex(5);
        comboBox_arm_6->setCurrentIndex(6);
        comboBox_drive_control->setCurrentIndex(0);
        pushButton_stop->setDefault(false);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        actionMain_Page->setText(QCoreApplication::translate("MainWindow", "Main Page", nullptr));
        actionfd->setText(QCoreApplication::translate("MainWindow", "fd", nullptr));
        groupBoxArm->setTitle(QCoreApplication::translate("MainWindow", "Arm", nullptr));
        label_Z->setText(QCoreApplication::translate("MainWindow", "Z Axis", nullptr));
        comboBox_arm_1->setItemText(0, QCoreApplication::translate("MainWindow", "--None--", nullptr));
        comboBox_arm_1->setItemText(1, QCoreApplication::translate("MainWindow", "First Segment", nullptr));
        comboBox_arm_1->setItemText(2, QCoreApplication::translate("MainWindow", "Second Segment", nullptr));
        comboBox_arm_1->setItemText(3, QCoreApplication::translate("MainWindow", "Third Segment", nullptr));
        comboBox_arm_1->setItemText(4, QCoreApplication::translate("MainWindow", "Jaws", nullptr));
        comboBox_arm_1->setItemText(5, QCoreApplication::translate("MainWindow", "All", nullptr));
        comboBox_arm_1->setItemText(6, QCoreApplication::translate("MainWindow", "Inverse Kinematics", nullptr));

        comboBox_arm_1->setCurrentText(QCoreApplication::translate("MainWindow", "First Segment", nullptr));
        label_z_arm->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        comboBox_arm_2->setItemText(0, QCoreApplication::translate("MainWindow", "--None--", nullptr));
        comboBox_arm_2->setItemText(1, QCoreApplication::translate("MainWindow", "First Segment", nullptr));
        comboBox_arm_2->setItemText(2, QCoreApplication::translate("MainWindow", "Second Segment", nullptr));
        comboBox_arm_2->setItemText(3, QCoreApplication::translate("MainWindow", "Third Segment", nullptr));
        comboBox_arm_2->setItemText(4, QCoreApplication::translate("MainWindow", "Jaws", nullptr));
        comboBox_arm_2->setItemText(5, QCoreApplication::translate("MainWindow", "All", nullptr));
        comboBox_arm_2->setItemText(6, QCoreApplication::translate("MainWindow", "Inverse Kinematics", nullptr));

        comboBox_arm_2->setCurrentText(QCoreApplication::translate("MainWindow", "Second Segment", nullptr));
        comboBox_arm_3->setItemText(0, QCoreApplication::translate("MainWindow", "--None--", nullptr));
        comboBox_arm_3->setItemText(1, QCoreApplication::translate("MainWindow", "First Segment", nullptr));
        comboBox_arm_3->setItemText(2, QCoreApplication::translate("MainWindow", "Second Segment", nullptr));
        comboBox_arm_3->setItemText(3, QCoreApplication::translate("MainWindow", "Third Segment", nullptr));
        comboBox_arm_3->setItemText(4, QCoreApplication::translate("MainWindow", "Jaws", nullptr));
        comboBox_arm_3->setItemText(5, QCoreApplication::translate("MainWindow", "All", nullptr));
        comboBox_arm_3->setItemText(6, QCoreApplication::translate("MainWindow", "Inverse Kinematics", nullptr));

        comboBox_arm_4->setItemText(0, QCoreApplication::translate("MainWindow", "--None--", nullptr));
        comboBox_arm_4->setItemText(1, QCoreApplication::translate("MainWindow", "First Segment", nullptr));
        comboBox_arm_4->setItemText(2, QCoreApplication::translate("MainWindow", "Second Segment", nullptr));
        comboBox_arm_4->setItemText(3, QCoreApplication::translate("MainWindow", "Third Segment", nullptr));
        comboBox_arm_4->setItemText(4, QCoreApplication::translate("MainWindow", "Jaws", nullptr));
        comboBox_arm_4->setItemText(5, QCoreApplication::translate("MainWindow", "All", nullptr));
        comboBox_arm_4->setItemText(6, QCoreApplication::translate("MainWindow", "Inverse Kinematics", nullptr));

        comboBox_arm_5->setItemText(0, QCoreApplication::translate("MainWindow", "--None--", nullptr));
        comboBox_arm_5->setItemText(1, QCoreApplication::translate("MainWindow", "First Segment", nullptr));
        comboBox_arm_5->setItemText(2, QCoreApplication::translate("MainWindow", "Second Segment", nullptr));
        comboBox_arm_5->setItemText(3, QCoreApplication::translate("MainWindow", "Third Segment", nullptr));
        comboBox_arm_5->setItemText(4, QCoreApplication::translate("MainWindow", "Jaws", nullptr));
        comboBox_arm_5->setItemText(5, QCoreApplication::translate("MainWindow", "All", nullptr));
        comboBox_arm_5->setItemText(6, QCoreApplication::translate("MainWindow", "Inverse Kinematics", nullptr));

        comboBox_arm_6->setItemText(0, QCoreApplication::translate("MainWindow", "--None--", nullptr));
        comboBox_arm_6->setItemText(1, QCoreApplication::translate("MainWindow", "First Segment", nullptr));
        comboBox_arm_6->setItemText(2, QCoreApplication::translate("MainWindow", "Second Segment", nullptr));
        comboBox_arm_6->setItemText(3, QCoreApplication::translate("MainWindow", "Third Segment", nullptr));
        comboBox_arm_6->setItemText(4, QCoreApplication::translate("MainWindow", "Jaws", nullptr));
        comboBox_arm_6->setItemText(5, QCoreApplication::translate("MainWindow", "All", nullptr));
        comboBox_arm_6->setItemText(6, QCoreApplication::translate("MainWindow", "Inverse Kinematics", nullptr));

        label_Y_2->setText(QCoreApplication::translate("MainWindow", "Y Axis", nullptr));
        label_y_arm->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        label_x_arm->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        label_POWER->setText(QCoreApplication::translate("MainWindow", "Power", nullptr));
        label_X_2->setText(QCoreApplication::translate("MainWindow", "X Axis", nullptr));
        pushButton_button_function_arm_1->setText(QCoreApplication::translate("MainWindow", "1", nullptr));
        pushButton_button_function_arm_2->setText(QCoreApplication::translate("MainWindow", "2", nullptr));
        pushButton_button_function_arm_3->setText(QCoreApplication::translate("MainWindow", "3", nullptr));
        pushButton_button_function_arm_4->setText(QCoreApplication::translate("MainWindow", "4", nullptr));
        pushButton_button_function_arm_5->setText(QCoreApplication::translate("MainWindow", "5", nullptr));
        pushButton_button_function_arm_6->setText(QCoreApplication::translate("MainWindow", "6", nullptr));
        progressBar_motor_base->setFormat(QCoreApplication::translate("MainWindow", "%v", nullptr));
        progressBar_motor_first->setFormat(QCoreApplication::translate("MainWindow", "%v", nullptr));
        progressBar_motor_second->setFormat(QCoreApplication::translate("MainWindow", "%v", nullptr));
        progressBar_motor_third->setFormat(QCoreApplication::translate("MainWindow", "%v", nullptr));
        progressBar_motor_jaws->setFormat(QCoreApplication::translate("MainWindow", "%v", nullptr));
        progressBar_motor_jaws_clench->setFormat(QCoreApplication::translate("MainWindow", "%v", nullptr));
        label_motor_base->setText(QCoreApplication::translate("MainWindow", "BASE", nullptr));
        label_motor_first->setText(QCoreApplication::translate("MainWindow", "FIRST", nullptr));
        label_motor_second->setText(QCoreApplication::translate("MainWindow", "SECOND", nullptr));
        label_motor_third->setText(QCoreApplication::translate("MainWindow", "THIRD", nullptr));
        label_motor_jaws->setText(QCoreApplication::translate("MainWindow", "JAWS", nullptr));
        label_motor_jaws_clench->setText(QCoreApplication::translate("MainWindow", "CLENCH", nullptr));
        groupBoxDrive->setTitle(QCoreApplication::translate("MainWindow", "Drive", nullptr));
        label_Y->setText(QCoreApplication::translate("MainWindow", "Y Axis", nullptr));
        label_y_drive->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        label_X->setText(QCoreApplication::translate("MainWindow", "X Axis", nullptr));
        label_power_drive->setText(QCoreApplication::translate("MainWindow", "Power", nullptr));
        label_x_drive->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        progressBar_wheel_left_back->setFormat(QCoreApplication::translate("MainWindow", "%v", nullptr));
        progressBar_wheel_left_middle->setFormat(QCoreApplication::translate("MainWindow", "%v", nullptr));
        progressBar_wheel_left_front->setFormat(QCoreApplication::translate("MainWindow", "%v", nullptr));
        progressBar_wheel_right_back->setFormat(QCoreApplication::translate("MainWindow", "%v", nullptr));
        progressBar_wheel_right_front->setFormat(QCoreApplication::translate("MainWindow", "%v", nullptr));
        progressBar_wheel_right_middle->setFormat(QCoreApplication::translate("MainWindow", "%v", nullptr));
        groupBox_4->setTitle(QCoreApplication::translate("MainWindow", "Compass / Map", nullptr));
        groupBox_7->setTitle(QCoreApplication::translate("MainWindow", "GPS List", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget_nav->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget_nav->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("MainWindow", "X - Geo Width", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget_nav->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("MainWindow", "Y- Geo Length", nullptr));
        label_18->setText(QCoreApplication::translate("MainWindow", "Longitude:", nullptr));
        label_19->setText(QCoreApplication::translate("MainWindow", "Latitude:", nullptr));
        pushButton_add_pos->setText(QCoreApplication::translate("MainWindow", "Add Pos", nullptr));
        label_22->setText(QCoreApplication::translate("MainWindow", "Index:", nullptr));
        labelChoosenIndex->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        pushButtonDeletePoint->setText(QCoreApplication::translate("MainWindow", "Remove", nullptr));
        pushButtonUnZoom->setText(QCoreApplication::translate("MainWindow", "-", nullptr));
        pushButtonZoom->setText(QCoreApplication::translate("MainWindow", "+", nullptr));
        label_scale->setText(QCoreApplication::translate("MainWindow", "Map Scale", nullptr));
        pushButtonRotate->setText(QCoreApplication::translate("MainWindow", "Azimuth", nullptr));
        lineEditPosXRover->setText(QString());
        lineEditPosYRover->setText(QString());
        lineEditRotate->setText(QString());
        pushButtonSend->setText(QCoreApplication::translate("MainWindow", "Longitude Latitude", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "Load Points", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("MainWindow", "Fast Settings", nullptr));
        label_drive_control->setText(QCoreApplication::translate("MainWindow", "Drive", nullptr));
        label_arm_control->setText(QCoreApplication::translate("MainWindow", "Arm", nullptr));
        comboBox_arm_control->setItemText(0, QCoreApplication::translate("MainWindow", "Virtual Sliders", nullptr));
        comboBox_arm_control->setItemText(1, QCoreApplication::translate("MainWindow", "Physical Joystick 1", nullptr));
        comboBox_arm_control->setItemText(2, QCoreApplication::translate("MainWindow", "Physical Joystick 2", nullptr));

        comboBox_drive_control->setItemText(0, QCoreApplication::translate("MainWindow", "Virtual Joystick", nullptr));
        comboBox_drive_control->setItemText(1, QCoreApplication::translate("MainWindow", "Physical Joystick 1", nullptr));
        comboBox_drive_control->setItemText(2, QCoreApplication::translate("MainWindow", "Physical Joystick 2", nullptr));

        label_3->setText(QCoreApplication::translate("MainWindow", "IP Adress:", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "Port:", nullptr));
        lineEdit_IP_adress->setText(QCoreApplication::translate("MainWindow", "192.168.1.10", nullptr));
        lineEdit_port->setText(QCoreApplication::translate("MainWindow", "5150", nullptr));
        pushButton_stop->setText(QCoreApplication::translate("MainWindow", "STOP", nullptr));
        groupBox_8->setTitle(QCoreApplication::translate("MainWindow", "General Info", nullptr));
        label_frames_received_count->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        label_frames_sent_count->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "Sent Frames", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "Recieved Frames", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "Current IP", nullptr));
        label_current_ip->setText(QString());
        label_2->setText(QCoreApplication::translate("MainWindow", "Joysticks Initialized", nullptr));
        label_joysticks_count->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        groupBox->setTitle(QCoreApplication::translate("MainWindow", "Messages", nullptr));
        textBrowser_printer->setMarkdown(QString());
        textBrowser_printer->setHtml(QCoreApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
        groupBox_3->setTitle(QCoreApplication::translate("MainWindow", "Poker", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "Angle", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "Poke", nullptr));
        groupBox_5->setTitle(QCoreApplication::translate("MainWindow", "Science Mission", nullptr));
        label_science_revolver_value->setText(QCoreApplication::translate("MainWindow", "0", nullptr));
        checkBox_lid_1->setText(QCoreApplication::translate("MainWindow", "Lid 1", nullptr));
        checkBox_lid_2->setText(QCoreApplication::translate("MainWindow", "Lid 2", nullptr));
        checkBox_lid_3->setText(QCoreApplication::translate("MainWindow", "Lid 3", nullptr));
        checkBox_lid_4->setText(QCoreApplication::translate("MainWindow", "Lid 4", nullptr));
        checkBox_pump_3->setText(QCoreApplication::translate("MainWindow", "Pump 3", nullptr));
        checkBox_pump_4->setText(QCoreApplication::translate("MainWindow", "Pump 4", nullptr));
        checkBox_pump_1->setText(QCoreApplication::translate("MainWindow", "Pump 1", nullptr));
        checkBox_pump_2->setText(QCoreApplication::translate("MainWindow", "Pump 2", nullptr));
        label_science_revolver_name->setText(QCoreApplication::translate("MainWindow", "Revolver", nullptr));
        pushButton_revolver_plus->setText(QCoreApplication::translate("MainWindow", "+", nullptr));
        pushButton_revolver_minus->setText(QCoreApplication::translate("MainWindow", "-", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
