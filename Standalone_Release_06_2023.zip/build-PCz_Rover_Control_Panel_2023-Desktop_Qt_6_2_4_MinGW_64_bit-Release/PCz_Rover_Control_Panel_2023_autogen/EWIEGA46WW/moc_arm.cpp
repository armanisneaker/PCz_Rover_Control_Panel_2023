/****************************************************************************
** Meta object code from reading C++ file 'arm.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../PCz_Rover_Control_Panel_2023/arm.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'arm.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Arm_t {
    const uint offsetsAndSize[36];
    char stringdata0[299];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_Arm_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_Arm_t qt_meta_stringdata_Arm = {
    {
QT_MOC_LITERAL(0, 3), // "Arm"
QT_MOC_LITERAL(4, 21), // "controlVirtualSliders"
QT_MOC_LITERAL(26, 0), // ""
QT_MOC_LITERAL(27, 24), // "controlPhysicalJoystick1"
QT_MOC_LITERAL(52, 24), // "controlPhysicalJoystick2"
QT_MOC_LITERAL(77, 21), // "buttonFunctionChanged"
QT_MOC_LITERAL(99, 5), // "index"
QT_MOC_LITERAL(105, 16), // "motorBaseChanged"
QT_MOC_LITERAL(122, 5), // "value"
QT_MOC_LITERAL(128, 17), // "motorFirstChanged"
QT_MOC_LITERAL(146, 18), // "motorSecondChanged"
QT_MOC_LITERAL(165, 17), // "motorThirdChanged"
QT_MOC_LITERAL(183, 16), // "motorJawsChanged"
QT_MOC_LITERAL(200, 22), // "motorJawsClenchChanged"
QT_MOC_LITERAL(223, 20), // "processButtonPressed"
QT_MOC_LITERAL(244, 16), // "buttonPressedNow"
QT_MOC_LITERAL(261, 28), // "onButtonFunctionIndexChanged"
QT_MOC_LITERAL(290, 8) // "newIndex"

    },
    "Arm\0controlVirtualSliders\0\0"
    "controlPhysicalJoystick1\0"
    "controlPhysicalJoystick2\0buttonFunctionChanged\0"
    "index\0motorBaseChanged\0value\0"
    "motorFirstChanged\0motorSecondChanged\0"
    "motorThirdChanged\0motorJawsChanged\0"
    "motorJawsClenchChanged\0processButtonPressed\0"
    "buttonPressedNow\0onButtonFunctionIndexChanged\0"
    "newIndex"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Arm[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      10,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   86,    2, 0x06,    1 /* Public */,
       3,    0,   87,    2, 0x06,    2 /* Public */,
       4,    0,   88,    2, 0x06,    3 /* Public */,
       5,    1,   89,    2, 0x06,    4 /* Public */,
       7,    1,   92,    2, 0x06,    6 /* Public */,
       9,    1,   95,    2, 0x06,    8 /* Public */,
      10,    1,   98,    2, 0x06,   10 /* Public */,
      11,    1,  101,    2, 0x06,   12 /* Public */,
      12,    1,  104,    2, 0x06,   14 /* Public */,
      13,    1,  107,    2, 0x06,   16 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      14,    1,  110,    2, 0x0a,   18 /* Public */,
      16,    2,  113,    2, 0x0a,   20 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    6,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void, QMetaType::Int,    8,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,   15,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    6,   17,

       0        // eod
};

void Arm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Arm *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->controlVirtualSliders(); break;
        case 1: _t->controlPhysicalJoystick1(); break;
        case 2: _t->controlPhysicalJoystick2(); break;
        case 3: _t->buttonFunctionChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 4: _t->motorBaseChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->motorFirstChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 6: _t->motorSecondChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 7: _t->motorThirdChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 8: _t->motorJawsChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 9: _t->motorJawsClenchChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 10: _t->processButtonPressed((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 11: _t->onButtonFunctionIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Arm::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Arm::controlVirtualSliders)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Arm::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Arm::controlPhysicalJoystick1)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (Arm::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Arm::controlPhysicalJoystick2)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (Arm::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Arm::buttonFunctionChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (Arm::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Arm::motorBaseChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (Arm::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Arm::motorFirstChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (Arm::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Arm::motorSecondChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (Arm::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Arm::motorThirdChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (Arm::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Arm::motorJawsChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (Arm::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Arm::motorJawsClenchChanged)) {
                *result = 9;
                return;
            }
        }
    }
}

const QMetaObject Arm::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_Arm.offsetsAndSize,
    qt_meta_data_Arm,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_Arm_t
, QtPrivate::TypeAndForceComplete<Arm, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>


>,
    nullptr
} };


const QMetaObject *Arm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Arm::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Arm.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Arm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 12)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void Arm::controlVirtualSliders()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void Arm::controlPhysicalJoystick1()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void Arm::controlPhysicalJoystick2()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void Arm::buttonFunctionChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void Arm::motorBaseChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void Arm::motorFirstChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void Arm::motorSecondChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void Arm::motorThirdChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void Arm::motorJawsChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void Arm::motorJawsClenchChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
