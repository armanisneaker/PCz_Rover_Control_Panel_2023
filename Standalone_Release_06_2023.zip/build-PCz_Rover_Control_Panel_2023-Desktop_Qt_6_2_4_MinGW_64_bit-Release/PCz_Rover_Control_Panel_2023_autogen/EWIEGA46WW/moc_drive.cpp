/****************************************************************************
** Meta object code from reading C++ file 'drive.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../PCz_Rover_Control_Panel_2023/drive.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'drive.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Drive_t {
    const uint offsetsAndSize[32];
    char stringdata0[203];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_Drive_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_Drive_t qt_meta_stringdata_Drive = {
    {
QT_MOC_LITERAL(0, 5), // "Drive"
QT_MOC_LITERAL(6, 22), // "controlVirtualJoystick"
QT_MOC_LITERAL(29, 0), // ""
QT_MOC_LITERAL(30, 24), // "controlPhysicalJoystick1"
QT_MOC_LITERAL(55, 24), // "controlPhysicalJoystick2"
QT_MOC_LITERAL(80, 16), // "leftSpeedChanged"
QT_MOC_LITERAL(97, 7), // "int16_t"
QT_MOC_LITERAL(105, 9), // "leftSpeed"
QT_MOC_LITERAL(115, 17), // "rightSpeedChanged"
QT_MOC_LITERAL(133, 10), // "rightSpeed"
QT_MOC_LITERAL(144, 17), // "roverSpeedChanged"
QT_MOC_LITERAL(162, 8), // "speedKmh"
QT_MOC_LITERAL(171, 21), // "calculateWheelsSpeeds"
QT_MOC_LITERAL(193, 1), // "x"
QT_MOC_LITERAL(195, 1), // "y"
QT_MOC_LITERAL(197, 5) // "power"

    },
    "Drive\0controlVirtualJoystick\0\0"
    "controlPhysicalJoystick1\0"
    "controlPhysicalJoystick2\0leftSpeedChanged\0"
    "int16_t\0leftSpeed\0rightSpeedChanged\0"
    "rightSpeed\0roverSpeedChanged\0speedKmh\0"
    "calculateWheelsSpeeds\0x\0y\0power"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Drive[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   56,    2, 0x06,    1 /* Public */,
       3,    0,   57,    2, 0x06,    2 /* Public */,
       4,    0,   58,    2, 0x06,    3 /* Public */,
       5,    1,   59,    2, 0x06,    4 /* Public */,
       8,    1,   62,    2, 0x06,    6 /* Public */,
      10,    1,   65,    2, 0x06,    8 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      12,    3,   68,    2, 0x0a,   10 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 6,    9,
    QMetaType::Void, QMetaType::Double,   11,

 // slots: parameters
    QMetaType::Bool, QMetaType::Int, QMetaType::Int, QMetaType::Int,   13,   14,   15,

       0        // eod
};

void Drive::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Drive *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->controlVirtualJoystick(); break;
        case 1: _t->controlPhysicalJoystick1(); break;
        case 2: _t->controlPhysicalJoystick2(); break;
        case 3: _t->leftSpeedChanged((*reinterpret_cast< std::add_pointer_t<int16_t>>(_a[1]))); break;
        case 4: _t->rightSpeedChanged((*reinterpret_cast< std::add_pointer_t<int16_t>>(_a[1]))); break;
        case 5: _t->roverSpeedChanged((*reinterpret_cast< std::add_pointer_t<double>>(_a[1]))); break;
        case 6: { bool _r = _t->calculateWheelsSpeeds((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[3])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Drive::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Drive::controlVirtualJoystick)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Drive::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Drive::controlPhysicalJoystick1)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (Drive::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Drive::controlPhysicalJoystick2)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (Drive::*)(int16_t );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Drive::leftSpeedChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (Drive::*)(int16_t );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Drive::rightSpeedChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (Drive::*)(double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Drive::roverSpeedChanged)) {
                *result = 5;
                return;
            }
        }
    }
}

const QMetaObject Drive::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_Drive.offsetsAndSize,
    qt_meta_data_Drive,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_Drive_t
, QtPrivate::TypeAndForceComplete<Drive, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int16_t, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int16_t, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<double, std::false_type>
, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<const int, std::false_type>, QtPrivate::TypeAndForceComplete<const int, std::false_type>, QtPrivate::TypeAndForceComplete<const int, std::false_type>


>,
    nullptr
} };


const QMetaObject *Drive::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Drive::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Drive.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Drive::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void Drive::controlVirtualJoystick()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void Drive::controlPhysicalJoystick1()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void Drive::controlPhysicalJoystick2()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void Drive::leftSpeedChanged(int16_t _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void Drive::rightSpeedChanged(int16_t _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void Drive::roverSpeedChanged(double _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
