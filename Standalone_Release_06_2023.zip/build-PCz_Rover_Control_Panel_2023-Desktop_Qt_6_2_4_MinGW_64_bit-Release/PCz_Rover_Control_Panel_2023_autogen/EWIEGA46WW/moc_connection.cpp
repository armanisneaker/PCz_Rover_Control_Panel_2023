/****************************************************************************
** Meta object code from reading C++ file 'connection.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../PCz_Rover_Control_Panel_2023/connection.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'connection.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Connection_t {
    const uint offsetsAndSize[58];
    char stringdata0[331];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_Connection_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_Connection_t qt_meta_stringdata_Connection = {
    {
QT_MOC_LITERAL(0, 10), // "Connection"
QT_MOC_LITERAL(11, 12), // "frameCreated"
QT_MOC_LITERAL(24, 0), // ""
QT_MOC_LITERAL(25, 9), // "frameSent"
QT_MOC_LITERAL(35, 13), // "frameReceived"
QT_MOC_LITERAL(49, 18), // "hostAddressChanged"
QT_MOC_LITERAL(68, 7), // "address"
QT_MOC_LITERAL(76, 15), // "hostPortChanged"
QT_MOC_LITERAL(92, 4), // "port"
QT_MOC_LITERAL(97, 19), // "frameFailedToBeSent"
QT_MOC_LITERAL(117, 5), // "value"
QT_MOC_LITERAL(123, 16), // "currentIpChanged"
QT_MOC_LITERAL(140, 11), // "createFrame"
QT_MOC_LITERAL(152, 10), // "frameDrive"
QT_MOC_LITERAL(163, 8), // "frameArm"
QT_MOC_LITERAL(172, 10), // "framePoker"
QT_MOC_LITERAL(183, 12), // "frameScience"
QT_MOC_LITERAL(196, 9), // "sendFrame"
QT_MOC_LITERAL(206, 14), // "setHostAddress"
QT_MOC_LITERAL(221, 11), // "setHostPort"
QT_MOC_LITERAL(233, 23), // "processReceivedDatagram"
QT_MOC_LITERAL(257, 14), // "localIpAddress"
QT_MOC_LITERAL(272, 23), // "byteArrayToBinaryString"
QT_MOC_LITERAL(296, 9), // "byteArray"
QT_MOC_LITERAL(306, 12), // "bytesToFloat"
QT_MOC_LITERAL(319, 2), // "b0"
QT_MOC_LITERAL(322, 2), // "b1"
QT_MOC_LITERAL(325, 2), // "b2"
QT_MOC_LITERAL(328, 2) // "b3"

    },
    "Connection\0frameCreated\0\0frameSent\0"
    "frameReceived\0hostAddressChanged\0"
    "address\0hostPortChanged\0port\0"
    "frameFailedToBeSent\0value\0currentIpChanged\0"
    "createFrame\0frameDrive\0frameArm\0"
    "framePoker\0frameScience\0sendFrame\0"
    "setHostAddress\0setHostPort\0"
    "processReceivedDatagram\0localIpAddress\0"
    "byteArrayToBinaryString\0byteArray\0"
    "bytesToFloat\0b0\0b1\0b2\0b3"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Connection[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  104,    2, 0x06,    1 /* Public */,
       3,    0,  105,    2, 0x06,    2 /* Public */,
       4,    0,  106,    2, 0x06,    3 /* Public */,
       5,    1,  107,    2, 0x06,    4 /* Public */,
       7,    1,  110,    2, 0x06,    6 /* Public */,
       9,    1,  113,    2, 0x06,    8 /* Public */,
      11,    1,  116,    2, 0x06,   10 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      12,    4,  119,    2, 0x0a,   12 /* Public */,
      17,    0,  128,    2, 0x0a,   17 /* Public */,
      18,    1,  129,    2, 0x0a,   18 /* Public */,
      19,    1,  132,    2, 0x0a,   20 /* Public */,
      20,    0,  135,    2, 0x0a,   22 /* Public */,
      21,    0,  136,    2, 0x0a,   23 /* Public */,
      22,    1,  137,    2, 0x0a,   24 /* Public */,
      24,    4,  140,    2, 0x0a,   26 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::UShort,    8,
    QMetaType::Void, QMetaType::Int,   10,
    QMetaType::Void, QMetaType::QString,   10,

 // slots: parameters
    QMetaType::Bool, QMetaType::QByteArray, QMetaType::QByteArray, QMetaType::QByteArray, QMetaType::QByteArray,   13,   14,   15,   16,
    QMetaType::Bool,
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::UShort,    8,
    QMetaType::Void,
    QMetaType::QString,
    QMetaType::QString, QMetaType::QByteArray,   23,
    QMetaType::Float, QMetaType::UChar, QMetaType::UChar, QMetaType::UChar, QMetaType::UChar,   25,   26,   27,   28,

       0        // eod
};

void Connection::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Connection *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->frameCreated(); break;
        case 1: _t->frameSent(); break;
        case 2: _t->frameReceived(); break;
        case 3: _t->hostAddressChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 4: _t->hostPortChanged((*reinterpret_cast< std::add_pointer_t<quint16>>(_a[1]))); break;
        case 5: _t->frameFailedToBeSent((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 6: _t->currentIpChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 7: { bool _r = _t->createFrame((*reinterpret_cast< std::add_pointer_t<QByteArray>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QByteArray>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QByteArray>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<QByteArray>>(_a[4])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 8: { bool _r = _t->sendFrame();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 9: _t->setHostAddress((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 10: _t->setHostPort((*reinterpret_cast< std::add_pointer_t<quint16>>(_a[1]))); break;
        case 11: _t->processReceivedDatagram(); break;
        case 12: { QString _r = _t->localIpAddress();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 13: { QString _r = _t->byteArrayToBinaryString((*reinterpret_cast< std::add_pointer_t<QByteArray>>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 14: { float _r = _t->bytesToFloat((*reinterpret_cast< std::add_pointer_t<uchar>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<uchar>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<uchar>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<uchar>>(_a[4])));
            if (_a[0]) *reinterpret_cast< float*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Connection::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Connection::frameCreated)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Connection::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Connection::frameSent)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (Connection::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Connection::frameReceived)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (Connection::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Connection::hostAddressChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (Connection::*)(quint16 );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Connection::hostPortChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (Connection::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Connection::frameFailedToBeSent)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (Connection::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Connection::currentIpChanged)) {
                *result = 6;
                return;
            }
        }
    }
}

const QMetaObject Connection::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_Connection.offsetsAndSize,
    qt_meta_data_Connection,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_Connection_t
, QtPrivate::TypeAndForceComplete<Connection, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<quint16, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>
, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<const QByteArray &, std::false_type>, QtPrivate::TypeAndForceComplete<const QByteArray &, std::false_type>, QtPrivate::TypeAndForceComplete<const QByteArray &, std::false_type>, QtPrivate::TypeAndForceComplete<const QByteArray &, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<quint16, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<const QByteArray &, std::false_type>, QtPrivate::TypeAndForceComplete<float, std::false_type>, QtPrivate::TypeAndForceComplete<uchar, std::false_type>, QtPrivate::TypeAndForceComplete<uchar, std::false_type>, QtPrivate::TypeAndForceComplete<uchar, std::false_type>, QtPrivate::TypeAndForceComplete<uchar, std::false_type>


>,
    nullptr
} };


const QMetaObject *Connection::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Connection::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Connection.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Connection::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 15;
    }
    return _id;
}

// SIGNAL 0
void Connection::frameCreated()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void Connection::frameSent()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void Connection::frameReceived()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void Connection::hostAddressChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void Connection::hostPortChanged(quint16 _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void Connection::frameFailedToBeSent(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void Connection::currentIpChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
