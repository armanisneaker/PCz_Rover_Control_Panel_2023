/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../PCz_Rover_Control_Panel_2023/mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    const uint offsetsAndSize[94];
    char stringdata0[1049];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 10), // "MainWindow"
QT_MOC_LITERAL(11, 22), // "updateFrameStatusLabel"
QT_MOC_LITERAL(34, 0), // ""
QT_MOC_LITERAL(35, 30), // "updateFrameReceivedStatusLabel"
QT_MOC_LITERAL(66, 44), // "on_comboBox_drive_control_cur..."
QT_MOC_LITERAL(111, 4), // "arg1"
QT_MOC_LITERAL(116, 42), // "on_comboBox_arm_control_curre..."
QT_MOC_LITERAL(159, 40), // "on_horizontalSlider_x_arm_sli..."
QT_MOC_LITERAL(200, 40), // "on_horizontalSlider_y_arm_sli..."
QT_MOC_LITERAL(241, 40), // "on_horizontalSlider_z_arm_sli..."
QT_MOC_LITERAL(282, 42), // "on_horizontalSlider_x_drive_s..."
QT_MOC_LITERAL(325, 42), // "on_horizontalSlider_y_drive_s..."
QT_MOC_LITERAL(368, 18), // "updateButtonColors"
QT_MOC_LITERAL(387, 14), // "connectionSlot"
QT_MOC_LITERAL(402, 7), // "armSlot"
QT_MOC_LITERAL(410, 21), // "armControlVirtualSlot"
QT_MOC_LITERAL(432, 23), // "armControlPhysical1Slot"
QT_MOC_LITERAL(456, 23), // "armControlPhysical2Slot"
QT_MOC_LITERAL(480, 16), // "initializeTimers"
QT_MOC_LITERAL(497, 11), // "startTimers"
QT_MOC_LITERAL(509, 17), // "initializeClasses"
QT_MOC_LITERAL(527, 18), // "initializeBusiness"
QT_MOC_LITERAL(546, 12), // "initializeUi"
QT_MOC_LITERAL(559, 24), // "setupBusinessConnections"
QT_MOC_LITERAL(584, 18), // "setupUiConnections"
QT_MOC_LITERAL(603, 17), // "connectArmButtons"
QT_MOC_LITERAL(621, 17), // "setButtonFunction"
QT_MOC_LITERAL(639, 10), // "QComboBox*"
QT_MOC_LITERAL(650, 8), // "comboBox"
QT_MOC_LITERAL(659, 23), // "Arm::ButtonFunctionKey&"
QT_MOC_LITERAL(683, 17), // "buttonFunctionKey"
QT_MOC_LITERAL(701, 9), // "driveSlot"
QT_MOC_LITERAL(711, 23), // "driveControlVirtualSlot"
QT_MOC_LITERAL(735, 25), // "driveControlPhysical1Slot"
QT_MOC_LITERAL(761, 25), // "driveControlPhysical2Slot"
QT_MOC_LITERAL(787, 13), // "deleteClasses"
QT_MOC_LITERAL(801, 12), // "deleteTimers"
QT_MOC_LITERAL(814, 29), // "on_pushButton_add_pos_clicked"
QT_MOC_LITERAL(844, 32), // "on_pushButtonDeletePoint_clicked"
QT_MOC_LITERAL(877, 25), // "on_pushButtonSend_clicked"
QT_MOC_LITERAL(903, 27), // "on_pushButtonRotate_clicked"
QT_MOC_LITERAL(931, 25), // "on_pushButtonZoom_clicked"
QT_MOC_LITERAL(957, 27), // "on_pushButtonUnZoom_clicked"
QT_MOC_LITERAL(985, 30), // "on_tableWidget_nav_cellClicked"
QT_MOC_LITERAL(1016, 3), // "row"
QT_MOC_LITERAL(1020, 6), // "column"
QT_MOC_LITERAL(1027, 21) // "on_pushButton_clicked"

    },
    "MainWindow\0updateFrameStatusLabel\0\0"
    "updateFrameReceivedStatusLabel\0"
    "on_comboBox_drive_control_currentTextChanged\0"
    "arg1\0on_comboBox_arm_control_currentTextChanged\0"
    "on_horizontalSlider_x_arm_sliderReleased\0"
    "on_horizontalSlider_y_arm_sliderReleased\0"
    "on_horizontalSlider_z_arm_sliderReleased\0"
    "on_horizontalSlider_x_drive_sliderReleased\0"
    "on_horizontalSlider_y_drive_sliderReleased\0"
    "updateButtonColors\0connectionSlot\0"
    "armSlot\0armControlVirtualSlot\0"
    "armControlPhysical1Slot\0armControlPhysical2Slot\0"
    "initializeTimers\0startTimers\0"
    "initializeClasses\0initializeBusiness\0"
    "initializeUi\0setupBusinessConnections\0"
    "setupUiConnections\0connectArmButtons\0"
    "setButtonFunction\0QComboBox*\0comboBox\0"
    "Arm::ButtonFunctionKey&\0buttonFunctionKey\0"
    "driveSlot\0driveControlVirtualSlot\0"
    "driveControlPhysical1Slot\0"
    "driveControlPhysical2Slot\0deleteClasses\0"
    "deleteTimers\0on_pushButton_add_pos_clicked\0"
    "on_pushButtonDeletePoint_clicked\0"
    "on_pushButtonSend_clicked\0"
    "on_pushButtonRotate_clicked\0"
    "on_pushButtonZoom_clicked\0"
    "on_pushButtonUnZoom_clicked\0"
    "on_tableWidget_nav_cellClicked\0row\0"
    "column\0on_pushButton_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      38,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  242,    2, 0x08,    1 /* Private */,
       3,    0,  243,    2, 0x08,    2 /* Private */,
       4,    1,  244,    2, 0x08,    3 /* Private */,
       6,    1,  247,    2, 0x08,    5 /* Private */,
       7,    0,  250,    2, 0x08,    7 /* Private */,
       8,    0,  251,    2, 0x08,    8 /* Private */,
       9,    0,  252,    2, 0x08,    9 /* Private */,
      10,    0,  253,    2, 0x08,   10 /* Private */,
      11,    0,  254,    2, 0x08,   11 /* Private */,
      12,    0,  255,    2, 0x08,   12 /* Private */,
      13,    0,  256,    2, 0x08,   13 /* Private */,
      14,    0,  257,    2, 0x08,   14 /* Private */,
      15,    0,  258,    2, 0x08,   15 /* Private */,
      16,    0,  259,    2, 0x08,   16 /* Private */,
      17,    0,  260,    2, 0x08,   17 /* Private */,
      18,    0,  261,    2, 0x08,   18 /* Private */,
      19,    0,  262,    2, 0x08,   19 /* Private */,
      20,    0,  263,    2, 0x08,   20 /* Private */,
      21,    0,  264,    2, 0x08,   21 /* Private */,
      22,    0,  265,    2, 0x08,   22 /* Private */,
      23,    0,  266,    2, 0x08,   23 /* Private */,
      24,    0,  267,    2, 0x08,   24 /* Private */,
      25,    0,  268,    2, 0x08,   25 /* Private */,
      26,    2,  269,    2, 0x08,   26 /* Private */,
      31,    0,  274,    2, 0x08,   29 /* Private */,
      32,    0,  275,    2, 0x08,   30 /* Private */,
      33,    0,  276,    2, 0x08,   31 /* Private */,
      34,    0,  277,    2, 0x08,   32 /* Private */,
      35,    0,  278,    2, 0x08,   33 /* Private */,
      36,    0,  279,    2, 0x08,   34 /* Private */,
      37,    0,  280,    2, 0x08,   35 /* Private */,
      38,    0,  281,    2, 0x08,   36 /* Private */,
      39,    0,  282,    2, 0x08,   37 /* Private */,
      40,    0,  283,    2, 0x08,   38 /* Private */,
      41,    0,  284,    2, 0x08,   39 /* Private */,
      42,    0,  285,    2, 0x08,   40 /* Private */,
      43,    2,  286,    2, 0x08,   41 /* Private */,
      46,    0,  291,    2, 0x08,   44 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void, QMetaType::QString,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 27, 0x80000000 | 29,   28,   30,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   44,   45,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->updateFrameStatusLabel(); break;
        case 1: _t->updateFrameReceivedStatusLabel(); break;
        case 2: _t->on_comboBox_drive_control_currentTextChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 3: _t->on_comboBox_arm_control_currentTextChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 4: _t->on_horizontalSlider_x_arm_sliderReleased(); break;
        case 5: _t->on_horizontalSlider_y_arm_sliderReleased(); break;
        case 6: _t->on_horizontalSlider_z_arm_sliderReleased(); break;
        case 7: _t->on_horizontalSlider_x_drive_sliderReleased(); break;
        case 8: _t->on_horizontalSlider_y_drive_sliderReleased(); break;
        case 9: _t->updateButtonColors(); break;
        case 10: _t->connectionSlot(); break;
        case 11: _t->armSlot(); break;
        case 12: _t->armControlVirtualSlot(); break;
        case 13: _t->armControlPhysical1Slot(); break;
        case 14: _t->armControlPhysical2Slot(); break;
        case 15: _t->initializeTimers(); break;
        case 16: _t->startTimers(); break;
        case 17: _t->initializeClasses(); break;
        case 18: _t->initializeBusiness(); break;
        case 19: _t->initializeUi(); break;
        case 20: _t->setupBusinessConnections(); break;
        case 21: _t->setupUiConnections(); break;
        case 22: _t->connectArmButtons(); break;
        case 23: _t->setButtonFunction((*reinterpret_cast< std::add_pointer_t<QComboBox*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<Arm::ButtonFunctionKey&>>(_a[2]))); break;
        case 24: _t->driveSlot(); break;
        case 25: _t->driveControlVirtualSlot(); break;
        case 26: _t->driveControlPhysical1Slot(); break;
        case 27: _t->driveControlPhysical2Slot(); break;
        case 28: _t->deleteClasses(); break;
        case 29: _t->deleteTimers(); break;
        case 30: _t->on_pushButton_add_pos_clicked(); break;
        case 31: _t->on_pushButtonDeletePoint_clicked(); break;
        case 32: _t->on_pushButtonSend_clicked(); break;
        case 33: _t->on_pushButtonRotate_clicked(); break;
        case 34: _t->on_pushButtonZoom_clicked(); break;
        case 35: _t->on_pushButtonUnZoom_clicked(); break;
        case 36: _t->on_tableWidget_nav_cellClicked((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 37: _t->on_pushButton_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSize,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t
, QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QComboBox *, std::false_type>, QtPrivate::TypeAndForceComplete<Arm::ButtonFunctionKey &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 38)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 38;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 38)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 38;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
