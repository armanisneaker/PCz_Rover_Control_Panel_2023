/****************************************************************************
** Meta object code from reading C++ file 'joystickdirectinput.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../PCz_Rover_Control_Panel_2023/joystickdirectinput.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'joystickdirectinput.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_DirectInputJoystick_t {
    const uint offsetsAndSize[40];
    char stringdata0[379];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_DirectInputJoystick_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_DirectInputJoystick_t qt_meta_stringdata_DirectInputJoystick = {
    {
QT_MOC_LITERAL(0, 19), // "DirectInputJoystick"
QT_MOC_LITERAL(20, 21), // "joystick1AxisXChanged"
QT_MOC_LITERAL(42, 0), // ""
QT_MOC_LITERAL(43, 5), // "value"
QT_MOC_LITERAL(49, 21), // "joystick1AxisYChanged"
QT_MOC_LITERAL(71, 21), // "joystick1AxisZChanged"
QT_MOC_LITERAL(93, 22), // "joystick1SliderChanged"
QT_MOC_LITERAL(116, 21), // "joystick2AxisXChanged"
QT_MOC_LITERAL(138, 21), // "joystick2AxisYChanged"
QT_MOC_LITERAL(160, 21), // "joystick2AxisZChanged"
QT_MOC_LITERAL(182, 22), // "joystick2SliderChanged"
QT_MOC_LITERAL(205, 27), // "joystick1ButtonStateChanged"
QT_MOC_LITERAL(233, 6), // "button"
QT_MOC_LITERAL(240, 7), // "pressed"
QT_MOC_LITERAL(248, 27), // "joystick2ButtonStateChanged"
QT_MOC_LITERAL(276, 29), // "connectedJoystickCountChanged"
QT_MOC_LITERAL(306, 5), // "count"
QT_MOC_LITERAL(312, 23), // "joystick1ButtonReleased"
QT_MOC_LITERAL(336, 23), // "joystick2ButtonReleased"
QT_MOC_LITERAL(360, 18) // "checkJoystickCount"

    },
    "DirectInputJoystick\0joystick1AxisXChanged\0"
    "\0value\0joystick1AxisYChanged\0"
    "joystick1AxisZChanged\0joystick1SliderChanged\0"
    "joystick2AxisXChanged\0joystick2AxisYChanged\0"
    "joystick2AxisZChanged\0joystick2SliderChanged\0"
    "joystick1ButtonStateChanged\0button\0"
    "pressed\0joystick2ButtonStateChanged\0"
    "connectedJoystickCountChanged\0count\0"
    "joystick1ButtonReleased\0joystick2ButtonReleased\0"
    "checkJoystickCount"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_DirectInputJoystick[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      13,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   98,    2, 0x06,    1 /* Public */,
       4,    1,  101,    2, 0x06,    3 /* Public */,
       5,    1,  104,    2, 0x06,    5 /* Public */,
       6,    1,  107,    2, 0x06,    7 /* Public */,
       7,    1,  110,    2, 0x06,    9 /* Public */,
       8,    1,  113,    2, 0x06,   11 /* Public */,
       9,    1,  116,    2, 0x06,   13 /* Public */,
      10,    1,  119,    2, 0x06,   15 /* Public */,
      11,    2,  122,    2, 0x06,   17 /* Public */,
      14,    2,  127,    2, 0x06,   20 /* Public */,
      15,    1,  132,    2, 0x06,   23 /* Public */,
      17,    1,  135,    2, 0x06,   25 /* Public */,
      18,    1,  138,    2, 0x06,   27 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      19,    0,  141,    2, 0x08,   29 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,   12,   13,
    QMetaType::Void, QMetaType::Int, QMetaType::Bool,   12,   13,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   12,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void DirectInputJoystick::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<DirectInputJoystick *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->joystick1AxisXChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 1: _t->joystick1AxisYChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 2: _t->joystick1AxisZChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 3: _t->joystick1SliderChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 4: _t->joystick2AxisXChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 5: _t->joystick2AxisYChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 6: _t->joystick2AxisZChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 7: _t->joystick2SliderChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 8: _t->joystick1ButtonStateChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 9: _t->joystick2ButtonStateChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 10: _t->connectedJoystickCountChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 11: _t->joystick1ButtonReleased((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 12: _t->joystick2ButtonReleased((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 13: _t->checkJoystickCount(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (DirectInputJoystick::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DirectInputJoystick::joystick1AxisXChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (DirectInputJoystick::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DirectInputJoystick::joystick1AxisYChanged)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (DirectInputJoystick::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DirectInputJoystick::joystick1AxisZChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (DirectInputJoystick::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DirectInputJoystick::joystick1SliderChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (DirectInputJoystick::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DirectInputJoystick::joystick2AxisXChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (DirectInputJoystick::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DirectInputJoystick::joystick2AxisYChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (DirectInputJoystick::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DirectInputJoystick::joystick2AxisZChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (DirectInputJoystick::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DirectInputJoystick::joystick2SliderChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (DirectInputJoystick::*)(int , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DirectInputJoystick::joystick1ButtonStateChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (DirectInputJoystick::*)(int , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DirectInputJoystick::joystick2ButtonStateChanged)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (DirectInputJoystick::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DirectInputJoystick::connectedJoystickCountChanged)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (DirectInputJoystick::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DirectInputJoystick::joystick1ButtonReleased)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (DirectInputJoystick::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DirectInputJoystick::joystick2ButtonReleased)) {
                *result = 12;
                return;
            }
        }
    }
}

const QMetaObject DirectInputJoystick::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_DirectInputJoystick.offsetsAndSize,
    qt_meta_data_DirectInputJoystick,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_DirectInputJoystick_t
, QtPrivate::TypeAndForceComplete<DirectInputJoystick, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *DirectInputJoystick::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *DirectInputJoystick::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_DirectInputJoystick.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int DirectInputJoystick::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 14;
    }
    return _id;
}

// SIGNAL 0
void DirectInputJoystick::joystick1AxisXChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void DirectInputJoystick::joystick1AxisYChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void DirectInputJoystick::joystick1AxisZChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void DirectInputJoystick::joystick1SliderChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void DirectInputJoystick::joystick2AxisXChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void DirectInputJoystick::joystick2AxisYChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void DirectInputJoystick::joystick2AxisZChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void DirectInputJoystick::joystick2SliderChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void DirectInputJoystick::joystick1ButtonStateChanged(int _t1, bool _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void DirectInputJoystick::joystick2ButtonStateChanged(int _t1, bool _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void DirectInputJoystick::connectedJoystickCountChanged(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void DirectInputJoystick::joystick1ButtonReleased(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void DirectInputJoystick::joystick2ButtonReleased(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
